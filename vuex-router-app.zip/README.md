# vuex-router-app

## Project setup
```
npm install
```

## Json Server Setup
```
npm install -g json-server
```

## Start Rest API
```
json-server --watch db.json
```


### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your tests
```
npm run test
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
