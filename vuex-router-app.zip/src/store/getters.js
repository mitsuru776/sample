export default {
  productList: (state) => {
    return state.productList;
  }

}