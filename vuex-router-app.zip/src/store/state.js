export default {
  productList: []
}