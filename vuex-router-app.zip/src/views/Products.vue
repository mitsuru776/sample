<template>
  <ListProduct />
</template>

<script>
import ListProduct from '@/components/ListProduct.vue'
export default {
  components: {
    ListProduct
  }

}
</script>

<style>

</style>
