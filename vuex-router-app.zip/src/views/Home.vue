<template>
  <AddProduct />
</template>

<script>
// @ is an alias to /src
import AddProduct from '@/components/AddProduct.vue'
export default {
  name: 'home',
  components: {
    AddProduct
  }
}
</script>
