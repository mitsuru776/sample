var app = new Vue({
    el: "#app",
    data: {
        color: 'green'
    }
}) 