var app = new Vue({
    el: "#app",
    data: {
        product: "sunglasses",
        quantity: 150,
        sale: true
    }
}) 