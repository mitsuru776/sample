var app = new Vue({
    el: "#app",
    data: {
        users: ["alice", "bob", "batman", "robin", "superman"]
    }
}) 