from django.contrib import admin
from profiles.models import Profile, ProfileStatus

admin.site.register(Profile)
admin.site.register(ProfileStatus)
